# BazaCode V2 — Developer Studio

Локальная мини-IDE с редактором кода, вкладками файлов, встроенной консолью, HTML-превью, ZIP-экспортом и AI-панелью Claude Opus 5.5.

## Возможности

- Подсветка синтаксиса для Python, JavaScript, HTML, CSS, JSON, Markdown и XML.
- Несколько файлов и вкладки; добавление, переименование и удаление файлов.
- Автосохранение рабочего пространства в `localStorage` браузера.
- Копирование кода и скачивание текущего файла.
- Экспорт всего проекта в ZIP.
- Встроенное HTML-превью (открывает HTML-файл в изолированном iframe).
- Консоль workspace-команд: `help`, `ls`, `cat <файл>`, `echo <текст>`, `status`, `clear`.
- AI-панель с Claude Opus 5.5 через официальный Anthropic API.

## Запуск

Требуется Python 3.10+.

### Windows (PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:ANTHROPIC_API_KEY="ваш_новый_Anthropic_API_key"
python app.py
```

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY="ваш_новый_Anthropic_API_key"
python app.py
```

После запуска открой `http://127.0.0.1:5000`.

Можно запустить без API-ключа: редактор, файлы, консоль и ZIP-экспорт продолжат работать. AI-панель будет сообщать, что ключ не настроен.

## Важно о ключе API

- Не вставляй API-ключ в `app.py`, `app.js`, HTML, ZIP-проект или публичный репозиторий.
- Используй переменную окружения `ANTHROPIC_API_KEY`.
- API-вызовы Claude могут тарифицироваться отдельно согласно условиям Anthropic.
- Для сетевой работы браузеру нужен интернет: CodeMirror и шрифты подключаются с CDN.

Модель API: `claude-opus-5-5`.
