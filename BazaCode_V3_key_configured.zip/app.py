import io
import os
import re
import zipfile
from pathlib import PurePosixPath

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, send_file

load_dotenv()  # Загружает ключ из локального .env

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024

MODEL_ID = "claude-opus-5-5"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"


@app.get("/")
def index():
    return render_template("index.html", model_id=MODEL_ID)


def clean_project_name(value):
    value = re.sub(r"[^a-zA-Z0-9_-]", "_", str(value or "BazaProject"))[:48]
    return value or "BazaProject"


def clean_relative_path(value):
    raw = str(value or "untitled.txt").replace("\\", "/").strip()
    path = PurePosixPath(raw)
    parts = [p for p in path.parts if p not in ("", ".", "..", "/")]
    cleaned = "/".join(parts)
    if not cleaned:
        cleaned = "untitled.txt"
    return cleaned[:180]


@app.post("/api/export")
def export_project():
    payload = request.get_json(silent=True) or {}
    project = clean_project_name(payload.get("project"))
    files = payload.get("files")
    if not isinstance(files, list) or len(files) > 80:
        return jsonify(error="Некорректный список файлов (максимум 80)."), 400

    memory_file = io.BytesIO()
    total_bytes = 0
    try:
        with zipfile.ZipFile(memory_file, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(
                f"{project}/README.md",
                f"# {project}\n\nCreated with BazaCode V2.\n"
            )
            for item in files:
                if not isinstance(item, dict):
                    continue
                filename = clean_relative_path(item.get("name"))
                content = str(item.get("content", ""))
                total_bytes += len(content.encode("utf-8"))
                if total_bytes > 2 * 1024 * 1024:
                    return jsonify(error="Суммарный размер файлов превышает 2 МБ."), 413
                archive.writestr(f"{project}/{filename}", content)
    except (TypeError, ValueError, zipfile.BadZipFile):
        return jsonify(error="Не удалось собрать ZIP-проект."), 400

    memory_file.seek(0)
    return send_file(
        memory_file,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"{project}.zip"
    )


@app.post("/api/chat")
def chat():
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not api_key:
        return jsonify(
            error="Не найден ANTHROPIC_API_KEY. Добавь свой ключ в переменные окружения и перезапусти BazaCode."
        ), 503

    payload = request.get_json(silent=True) or {}
    prompt = str(payload.get("prompt", "")).strip()
    files = payload.get("files", [])
    if not prompt:
        return jsonify(error="Напиши сообщение для Claude."), 400
    if len(prompt) > 12000:
        return jsonify(error="Сообщение слишком длинное (максимум 12 000 символов)."), 400
    if not isinstance(files, list):
        files = []

    context_parts = []
    total = 0
    for item in files[:12]:
        if not isinstance(item, dict):
            continue
        name = clean_relative_path(item.get("name"))
        content = str(item.get("content", ""))
        if len(content) > 12000:
            content = content[:12000] + "\n… [файл обрезан]"
        total += len(content)
        if total > 30000:
            break
        context_parts.append(f"--- FILE: {name} ---\n{content}")

    system_prompt = (
        "Ты — BazaCode AI, помощник по программированию. Отвечай на русском, "
        "если пользователь не попросил другой язык. Объясняй изменения понятно. "
        "Когда предлагаешь код, указывай имя файла и используй fenced code blocks. "
        "Не утверждай, что изменил файлы напрямую: ты только предлагаешь ответ."
    )
    user_message = prompt
    if context_parts:
        user_message += "\n\nКонтекст файлов проекта:\n" + "\n\n".join(context_parts)

    try:
        response = requests.post(
            ANTHROPIC_URL,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": MODEL_ID,
                "max_tokens": 2200,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_message}],
            },
            timeout=90,
        )
        data = response.json()
        if not response.ok:
            message = data.get("error", {}).get("message", "Ошибка Anthropic API.")
            return jsonify(error=f"Anthropic API: {message}"), response.status_code
        answer = "\n".join(
            block.get("text", "")
            for block in data.get("content", [])
            if block.get("type") == "text"
        ).strip()
        return jsonify(reply=answer or "Модель не вернула текстовый ответ.", model=MODEL_ID)
    except requests.Timeout:
        return jsonify(error="Превышено время ожидания ответа Claude. Попробуй ещё раз."), 504
    except requests.RequestException:
        return jsonify(error="Не удалось подключиться к Anthropic API."), 502
    except ValueError:
        return jsonify(error="Anthropic API вернул некорректный ответ."), 502


if __name__ == "__main__":
    # Local-only server. Keep your API key in the environment, never in frontend files.
    app.run(host="127.0.0.1", port=5000, debug=False)
