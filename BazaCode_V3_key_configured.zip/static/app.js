(() => {
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "bazacode-v2-workspace";
  let state = {
    project: "BazaProject",
    active: "main.py",
    files: {
      "main.py": 'print("Hello, BazaCode V2!")\n\n# Начни создавать что-нибудь крутое.\n'
    }
  };
  let editor;
  let saveTimer;

  const modes = {
    py: ["python", "PYTHON"], pyw: ["python", "PYTHON"],
    js: ["javascript", "JAVASCRIPT"], mjs: ["javascript", "JAVASCRIPT"], cjs: ["javascript", "JAVASCRIPT"],
    html: ["htmlmixed", "HTML"], htm: ["htmlmixed", "HTML"],
    css: ["css", "CSS"], json: [{name:"javascript", json:true}, "JSON"],
    md: ["markdown", "MARKDOWN"], txt: ["null", "TEXT"],
    xml: ["xml", "XML"], svg: ["xml", "SVG"]
  };
  const fileIcon = (name) => {
    const ext = (name.split(".").pop() || "").toLowerCase();
    return ({py:"Py",js:"JS",html:"<>",css:"#",json:"{}",md:"M",txt:"T",xml:"<>",svg:"S"})[ext] || "·";
  };
  const fileMode = (name) => modes[(name.split(".").pop() || "").toLowerCase()] || ["null", "TEXT"];
  const escapeText = (s) => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (saved && saved.files && Object.keys(saved.files).length) {
        state = saved;
      }
    } catch (_) {}
  }
  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      $("saveStatus").textContent = "Сохранено";
    } catch (_) {
      $("saveStatus").textContent = "Не сохранено";
    }
  }
  function queueSave() {
    $("saveStatus").textContent = "Сохранение…";
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveState, 250);
  }
  function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.style.display = "block";
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.style.display = "none", 2400);
  }
  function setProjectName(name) {
    state.project = name.trim() || "BazaProject";
    $("projectTitle").textContent = state.project;
    $("sidebarProject").textContent = state.project;
    document.title = `${state.project} — BazaCode V2`;
    queueSave();
  }
  function renderFiles() {
    const list = $("fileList");
    const tabs = $("tabs");
    list.replaceChildren();
    tabs.replaceChildren();
    Object.keys(state.files).forEach(name => {
      const item = document.createElement("button");
      item.className = "file-item" + (name === state.active ? " active" : "");
      item.innerHTML = `<span class="file-icon">${escapeText(fileIcon(name))}</span><span class="file-name">${escapeText(name)}</span>`;
      item.addEventListener("click", () => openFile(name));
      list.appendChild(item);

      const tab = document.createElement("div");
      tab.className = "tab" + (name === state.active ? " active" : "");
      tab.innerHTML = `<span class="tab-icon">${escapeText(fileIcon(name))}</span><span>${escapeText(name)}</span>`;
      tab.addEventListener("click", () => openFile(name));
      tabs.appendChild(tab);
    });
    $("activeFileLabel").textContent = state.active;
    $("languageLabel").textContent = fileMode(state.active)[1];
  }
  function updateStats() {
    const value = editor ? editor.getValue() : "";
    const lines = value.split("\n").length;
    $("lineCount").textContent = `${lines} ${lines === 1 ? "строка" : "строк"}`;
    $("charCount").textContent = `${value.length} символов`;
  }
  function refreshMode() {
    if (!editor) return;
    editor.setOption("mode", fileMode(state.active)[0]);
    $("languageLabel").textContent = fileMode(state.active)[1];
  }
  function openFile(name) {
    if (!(name in state.files)) return;
    if (editor) state.files[state.active] = editor.getValue();
    state.active = name;
    editor.setValue(state.files[name]);
    refreshMode();
    renderFiles();
    updateStats();
    queueSave();
  }
  function addFile() {
    let name = prompt("Имя нового файла (например, app.js или index.html):", "new_file.py");
    if (!name) return;
    name = name.trim().replace(/\\/g, "/").split("/").filter(p => p && p !== "." && p !== "..").join("/");
    if (!name) return toast("Некорректное имя файла.");
    if (state.files[name] !== undefined) return toast("Файл с таким именем уже существует.");
    state.files[name] = "";
    openFile(name);
    toast("Файл добавлен.");
  }
  function renameFile() {
    const next = prompt("Новое имя файла:", state.active);
    if (!next || !next.trim() || next === state.active) return;
    const name = next.trim().replace(/\\/g, "/").split("/").filter(p => p && p !== "." && p !== "..").join("/");
    if (!name) return toast("Некорректное имя.");
    if (state.files[name] !== undefined) return toast("Файл с таким именем уже существует.");
    state.files[state.active] = editor.getValue();
    state.files[name] = state.files[state.active];
    delete state.files[state.active];
    state.active = name;
    renderFiles();
    refreshMode();
    queueSave();
  }
  function deleteFile() {
    const names = Object.keys(state.files);
    if (names.length < 2) return toast("В проекте должен остаться хотя бы один файл.");
    if (!confirm(`Удалить ${state.active}?`)) return;
    delete state.files[state.active];
    state.active = Object.keys(state.files)[0];
    editor.setValue(state.files[state.active]);
    renderFiles();
    refreshMode();
    updateStats();
    queueSave();
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function exportZip() {
    state.files[state.active] = editor.getValue();
    const button = $("exportBtn");
    button.disabled = true;
    try {
      const response = await fetch("/api/export", {
        method: "POST", headers: {"Content-Type":"application/json"},
        body: JSON.stringify({project: state.project, files: Object.entries(state.files).map(([name,content])=>({name,content}))})
      });
      if (!response.ok) {
        const info = await response.json().catch(() => ({}));
        throw new Error(info.error || "Ошибка экспорта.");
      }
      downloadBlob(await response.blob(), `${state.project}.zip`);
      toast("ZIP всего проекта готов!");
    } catch (err) {
      toast(err.message || "Не удалось собрать ZIP.");
    } finally { button.disabled = false; }
  }
  function downloadCurrent() {
    downloadBlob(new Blob([editor.getValue()], {type:"text/plain;charset=utf-8"}), state.active.split("/").pop());
  }
  async function copyCode() {
    try {
      await navigator.clipboard.writeText(editor.getValue());
      toast("Код скопирован!");
    } catch (_) {
      editor.focus(); editor.execCommand("selectAll");
      document.execCommand("copy");
      toast("Код скопирован!");
    }
  }
  function addTerminalLine(text, kind="") {
    const line = document.createElement("div");
    line.className = "terminal-line " + kind;
    line.textContent = text;
    $("terminalOutput").appendChild(line);
    $("terminalOutput").scrollTop = $("terminalOutput").scrollHeight;
  }
  function runTerminalCommand(raw) {
    const command = raw.trim();
    if (!command) return;
    addTerminalLine("❯ " + command);
    const [op, ...rest] = command.split(" ");
    const arg = rest.join(" ");
    switch (op.toLowerCase()) {
      case "help":
        addTerminalLine("Команды: help · ls · cat <файл> · echo <текст> · status · clear");
        addTerminalLine("Это консоль BazaCode, а не системный shell. Произвольные команды ОС не запускаются.", "muted-line");
        break;
      case "ls":
        Object.keys(state.files).forEach(name => addTerminalLine("  " + name));
        break;
      case "cat":
        if (!arg) addTerminalLine("Использование: cat <имя_файла>");
        else if (state.files[arg] === undefined) addTerminalLine(`Файл не найден: ${arg}`);
        else addTerminalLine(state.files[arg] || "(пустой файл)");
        break;
      case "echo": addTerminalLine(arg); break;
      case "status":
        addTerminalLine(`Проект: ${state.project} · Файлов: ${Object.keys(state.files).length} · Активный: ${state.active}`);
        break;
      case "clear": $("terminalOutput").replaceChildren(); break;
      default: addTerminalLine(`Неизвестная команда: ${op}. Введи help.`, "muted-line");
    }
  }
  function previewHtml() {
    const htmlFile = state.files["index.html"] !== undefined ? "index.html" :
      Object.keys(state.files).find(name => name.toLowerCase().endsWith(".html"));
    if (!htmlFile) return toast("В проекте нет HTML-файла для предпросмотра.");
    state.files[state.active] = editor.getValue();
    const blob = new Blob([state.files[htmlFile]], {type:"text/html"});
    const url = URL.createObjectURL(blob);
    $("previewFrame").src = url;
    $("previewModal").classList.add("open");
    $("previewFrame")._blobUrl = url;
  }
  function addChatMessage(text, who) {
    if (who === "user") {
      const div = document.createElement("div");
      div.className = "user-message";
      div.textContent = text;
      $("chatMessages").appendChild(div);
    } else {
      const wrap = document.createElement("div");
      wrap.className = "ai-message";
      const avatar = document.createElement("div");
      avatar.className = "message-avatar";
      avatar.textContent = "✳";
      const body = document.createElement("div");
      body.className = "message-body";
      const strong = document.createElement("strong");
      strong.textContent = "Claude Opus 5.5";
      const p = document.createElement("p");
      p.textContent = text;
      body.append(strong,p);
      wrap.append(avatar,body);
      $("chatMessages").appendChild(wrap);
    }
    $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
  }
  async function askClaude(prompt) {
    const send = $("sendBtn");
    send.disabled = true;
    addChatMessage(prompt, "user");
    $("chatInput").value = "";
    addChatMessage("Claude думает…", "assistant");
    const thinking = $("chatMessages").lastElementChild;
    try {
      state.files[state.active] = editor.getValue();
      const files = Object.entries(state.files).map(([name,content])=>({name,content}));
      const response = await fetch("/api/chat", {
        method: "POST", headers: {"Content-Type":"application/json"},
        body: JSON.stringify({prompt, files})
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Не удалось получить ответ.");
      thinking.querySelector("p").textContent = data.reply;
    } catch (err) {
      thinking.querySelector("p").textContent = "Ошибка: " + (err.message || "Не удалось связаться с моделью.");
    } finally {
      send.disabled = false;
      $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
    }
  }
  function newProject() {
    if (!confirm("Создать новый проект? Несохранённые данные останутся только в текущем ZIP, если ты уже его экспортировал.")) return;
    state = {project:"BazaProject",active:"main.py",files:{"main.py":""}};
    setProjectName(state.project);
    editor.setValue("");
    renderFiles(); refreshMode(); updateStats(); saveState();
    addTerminalLine("Создан новый проект.");
  }

  loadState();
  $("projectTitle").textContent = state.project;
  $("sidebarProject").textContent = state.project;
  editor = CodeMirror.fromTextArea($("codeEditor"), {
    theme: "baza",
    mode: fileMode(state.active)[0],
    lineNumbers: true,
    indentUnit: 4,
    tabSize: 4,
    indentWithTabs: false,
    lineWrapping: false,
    autofocus: false,
    extraKeys: {"Tab": cm => cm.replaceSelection("    ", "end"), "Ctrl-S": () => {state.files[state.active]=editor.getValue();saveState();toast("Проект сохранён в браузере.");}}
  });
  editor.setValue(state.files[state.active] || "");
  editor.on("change", () => {
    state.files[state.active] = editor.getValue();
    updateStats();
    queueSave();
  });
  editor.on("cursorActivity", () => {
    const c = editor.getCursor();
    $("cursorPos").textContent = `Ln ${c.line+1}, Col ${c.ch+1}`;
  });

  $("addFileBtn").addEventListener("click", addFile);
  $("renameFileBtn").addEventListener("click", renameFile);
  $("deleteFileBtn").addEventListener("click", deleteFile);
  $("renameProjectBtn").addEventListener("click", () => {
    const name = prompt("Название проекта:", state.project);
    if (name !== null) setProjectName(name);
  });
  $("newProjectBtn").addEventListener("click", newProject);
  $("exportBtn").addEventListener("click", exportZip);
  $("downloadFileBtn").addEventListener("click", downloadCurrent);
  $("copyBtn").addEventListener("click", copyCode);
  $("previewBtn").addEventListener("click", previewHtml);
  $("symbolsBtn").addEventListener("click", () => {
    const choices = ["◆ ", "» ", "✦ ", "╰─ ", "⟡ ", "⟶ ", "𝙗𝙤𝙡𝙙 "];
    const chosen = prompt("Вставить символ в позицию курсора:\n1 — ◆   2 — »   3 — ✦   4 — ╰─   5 — ⟡   6 — ⟶   7 — 𝙗𝙤𝙡𝙙", "3");
    const index = Number(chosen) - 1;
    if (Number.isInteger(index) && index >= 0 && index < choices.length) {
      editor.replaceSelection(choices[index], "end");
      editor.focus();
    }
  });
  $("clearTerminalBtn").addEventListener("click", () => $("terminalOutput").replaceChildren());
  $("terminalForm").addEventListener("submit", e => {
    e.preventDefault();
    runTerminalCommand($("terminalInput").value);
    $("terminalInput").value = "";
  });
  $("chatForm").addEventListener("submit", e => {
    e.preventDefault();
    const prompt = $("chatInput").value.trim();
    if (prompt) askClaude(prompt);
  });
  document.querySelectorAll(".chip").forEach(btn => btn.addEventListener("click", () => askClaude(btn.dataset.prompt)));
  $("closePreviewBtn").addEventListener("click", () => {
    $("previewModal").classList.remove("open");
    const frame = $("previewFrame");
    frame.src = "about:blank";
    if (frame._blobUrl) URL.revokeObjectURL(frame._blobUrl);
  });
  $("previewModal").addEventListener("click", e => {
    if (e.target === $("previewModal")) $("closePreviewBtn").click();
  });

  renderFiles();
  refreshMode();
  updateStats();
  saveState();
  window.addEventListener("beforeunload", () => {
    if (editor) state.files[state.active] = editor.getValue();
    saveState();
  });
})();
